read 'icns' (128) "HYPHY.icns";
read 'icns' (129) "Docs.icns";
read 'plst' (0) "plist.xml";