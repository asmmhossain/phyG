package codesInterfaces;


public interface MatName {

	public static int I=0;
	public static int D=1;
	public static int M=2;
	public static String names[]= {"ins","del","match"};
}
