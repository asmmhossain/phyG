package utils;

public interface Named {

	public  String getName();
}
